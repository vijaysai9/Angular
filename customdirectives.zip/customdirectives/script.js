var app = angular.module('mainApp', []);

app.directive('myFirstScript', function() {	
	return {
		restrict: 'EA',
		scope: {
			name:'@' ,
			age: '=' ,
			func: '&'
		},
		template: ['<p>Value of name in directive: {{name}}</p>',
		            '<p>Enter new "name": <input type="text" ng-model="name"></p>',
		            '<p>Value of age in directive: {{age}}</p>',
		            '<p>Enter a new age: <input type="text" ng-model="age"></p>',
		            '<p><input type="button" value="Alert from directive" ng-click="func()"></p>'].join('')
	}
});

app.controller('app', function($scope){
   $scope.name = "vijay";
   $scope.age = 24;	
   $scope.alertTheName = function() {
   	 alert($scope.name);
   };
});